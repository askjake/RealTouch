#!/bin/bash
sudo systemctl restart isc-dhcp-server.service
